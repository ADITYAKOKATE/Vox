import React from 'react';
import { NavigationContainer } from '@react-navigation/native';
import { createNativeStackNavigator } from '@react-navigation/native-stack';
import LoginScreen from './screens/auth/LoginScreen';
import SignupScreen from './screens/auth/SignupScreen';
import CitizenNavigator from './screens/citizen/CitizenNavigator';
import StaffDashboard from './screens/staff/StaffDashboard';
import AdminDashboard from './screens/admin/AdminDashboard';
import IssueDetailsScreen from './screens/citizen/IssueDetailsScreen';

const Stack = createNativeStackNavigator();

export default function App() {
  return (
    <NavigationContainer>
      <Stack.Navigator initialRouteName="Login">
        <Stack.Screen
          name="Login"
          component={LoginScreen}
          options={{ headerShown: false }}
        />
        <Stack.Screen
          name="Signup"
          component={SignupScreen}
          options={{ headerShown: false }}
        />
        <Stack.Screen
          name="CitizenHome"
          component={CitizenNavigator}
          options={{ headerShown: false }}
        />
        <Stack.Screen
          name="IssueDetails"
          component={IssueDetailsScreen}
          options={{ headerTitle: 'Issue Details', headerShown: false }}
        />
        <Stack.Screen
          name="StaffHome"
          component={StaffDashboard}
          options={{ headerTitle: 'Staff Dashboard', headerShown: false }}
        />
        <Stack.Screen
          name="AdminHome"
          component={AdminDashboard}
          options={{ headerTitle: 'Admin Panel', headerShown: false }}
        />
      </Stack.Navigator>
    </NavigationContainer>
  );
}
