import axios from 'axios';
import { Platform } from 'react-native';
import AsyncStorage from '@react-native-async-storage/async-storage';

// Replace with your machine's IP address
// Android Emulator uses 10.0.2.2 usually, but for physical device use local IP
const ANDROID_API_URL = 'http://10.0.2.2:5000/api/v1';
const IOS_API_URL = 'http://localhost:5000/api/v1';
const PHYSICAL_DEVICE_URL = 'http://192.168.1.5:5000/api/v1'; // Update this!

// Use a helper or environment variable to switch
const baseURL = 'http://10.145.135.40:5000/api/v1';

const client = axios.create({
    baseURL,
    headers: {
        'Content-Type': 'application/json',
    },
});

// Add a request interceptor to attach the token
client.interceptors.request.use(
    async (config) => {
        const token = await AsyncStorage.getItem('userToken');
        if (token) {
            config.headers.Authorization = `Bearer ${token}`;
        }
        return config;
    },
    (error) => {
        return Promise.reject(error);
    }
);

export default client;
