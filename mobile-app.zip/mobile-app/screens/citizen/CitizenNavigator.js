import React from 'react';
import { createBottomTabNavigator } from '@react-navigation/bottom-tabs';
import { View, Platform } from 'react-native';
import { Ionicons } from '@expo/vector-icons';

import HomeScreen from './HomeScreen';
import MyIssuesScreen from './MyIssuesScreen';
import ReportScreen from './ReportScreen';
import MapScreen from './MapScreen';
import SettingsScreen from './SettingsScreen';

const Tab = createBottomTabNavigator();

const CitizenNavigator = () => {
    return (
        <Tab.Navigator
            screenOptions={({ route }) => ({
                headerShown: false,
                tabBarStyle: {
                    backgroundColor: '#ffffff',
                    borderTopWidth: 0,
                    elevation: 10,
                    shadowColor: '#000',
                    shadowOffset: { width: 0, height: -2 },
                    shadowOpacity: 0.1,
                    shadowRadius: 10,
                    height: Platform.OS === 'ios' ? 85 : 65,
                    paddingBottom: Platform.OS === 'ios' ? 30 : 10,
                    paddingTop: 10,
                    borderTopLeftRadius: 20,
                    borderTopRightRadius: 20,
                    position: 'absolute',
                },
                tabBarActiveTintColor: '#2E86DE',
                tabBarInactiveTintColor: '#95A5A6',
                tabBarLabelStyle: {
                    fontSize: 10,
                    fontFamily: Platform.OS === 'ios' ? 'System' : 'Roboto',
                },
                tabBarIcon: ({ focused, color, size }) => {
                    let iconName;

                    if (route.name === 'Home') {
                        iconName = focused ? 'home' : 'home-outline';
                    } else if (route.name === 'My Issues') {
                        iconName = focused ? 'document-text' : 'document-text-outline';
                    } else if (route.name === 'Report') {
                        iconName = 'add';
                    } else if (route.name === 'Map') {
                        iconName = focused ? 'map' : 'map-outline';
                    } else if (route.name === 'Settings') {
                        iconName = focused ? 'settings' : 'settings-outline';
                    }

                    // Special styling for Report button
                    if (route.name === 'Report') {
                        return (
                            <View
                                style={{
                                    top: -25,
                                    width: 60,
                                    height: 60,
                                    borderRadius: 30,
                                    backgroundColor: '#00D2D3', // Teal/Cyan color from mockup
                                    justifyContent: 'center',
                                    alignItems: 'center',
                                    shadowColor: '#00D2D3',
                                    shadowOffset: { width: 0, height: 5 },
                                    shadowOpacity: 0.5,
                                    shadowRadius: 10,
                                    elevation: 5,
                                }}
                            >
                                <Ionicons name="add" size={35} color="#fff" />
                            </View>
                        );
                    }

                    return <Ionicons name={iconName} size={size} color={color} />;
                },
            })}
        >
            <Tab.Screen name="Home" component={HomeScreen} />
            <Tab.Screen name="My Issues" component={MyIssuesScreen} />
            <Tab.Screen
                name="Report"
                component={ReportScreen}
                options={{
                    tabBarLabel: 'REPORT',
                    tabBarLabelStyle: {
                        fontSize: 10,
                        marginBottom: -20, // Hide the label or push it down
                        fontWeight: 'bold',
                        color: '#00D2D3'
                    }
                }}
            />
            <Tab.Screen name="Map" component={MapScreen} />
            <Tab.Screen name="Settings" component={SettingsScreen} />
        </Tab.Navigator>
    );
};

export default CitizenNavigator;
