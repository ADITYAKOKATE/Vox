import React, { useState, useEffect, useRef } from 'react';
import { View, Text, StyleSheet, ScrollView, TouchableOpacity, TextInput, Image, Dimensions, Alert, ActivityIndicator, Modal } from 'react-native';
import { SafeAreaView } from 'react-native-safe-area-context';
import { Ionicons } from '@expo/vector-icons';
import * as ImagePicker from 'expo-image-picker';
import * as Location from 'expo-location';
import { CameraView, useCameraPermissions, useMicrophonePermissions } from 'expo-camera';
import { useVideoPlayer, VideoView } from 'expo-video';
import AsyncStorage from '@react-native-async-storage/async-storage';
import client from '../../api/client';

const { width } = Dimensions.get('window');

const VideoPreview = ({ uri }) => {
    const player = useVideoPlayer(uri, player => {
        player.loop = true;
        player.play();
    });

    return (
        <VideoView
            style={styles.imagePreview}
            player={player}
            allowsFullscreen
            allowsPictureInPicture
        />
    );
};

const ReportScreen = ({ navigation }) => {
    const [media, setMedia] = useState(null); // Renamed from image to media
    const [description, setDescription] = useState('');
    const [category, setCategory] = useState('');
    const [isLoading, setIsLoading] = useState(false);

    // Camera State
    const [isCameraVisible, setIsCameraVisible] = useState(false);
    const [cameraMode, setCameraMode] = useState('picture'); // 'picture' | 'video'
    const [isRecording, setIsRecording] = useState(false);
    const [facing, setFacing] = useState('back');
    const [permission, requestPermission] = useCameraPermissions();
    const [micPermission, requestMicPermission] = useMicrophonePermissions();
    const cameraRef = useRef(null);

    // Location State
    const [location, setLocation] = useState(null);
    const [address, setAddress] = useState('Fetching location...');
    const [isLocationLoading, setIsLocationLoading] = useState(true);

    // Minimal dropdown implementation
    const [showDropdown, setShowDropdown] = useState(false);
    const categories = ['Pothole', 'Streetlight', 'Garbage', 'Water', 'Noise', 'Traffic', 'Other'];

    useEffect(() => {
        (async () => {
            try {
                let { status } = await Location.requestForegroundPermissionsAsync();
                if (status !== 'granted') {
                    Alert.alert('Permission to access location was denied');
                    setAddress('Location permission denied');
                    setIsLocationLoading(false);
                    return;
                }

                let loc = await Location.getCurrentPositionAsync({});
                setLocation(loc.coords);

                // Reverse Geocode
                let geocode = await Location.reverseGeocodeAsync({
                    latitude: loc.coords.latitude,
                    longitude: loc.coords.longitude
                });

                if (geocode.length > 0) {
                    const g = geocode[0];
                    const addr = `${g.street || ''} ${g.name || ''}, ${g.city || ''}`;
                    setAddress(addr.trim() || "Address not found");
                }
            } catch (error) {
                console.log(error);
                setAddress("Could not fetch location");
            } finally {
                setIsLocationLoading(false);
            }
        })();
    }, []);

    const refreshLocation = async () => {
        setIsLocationLoading(true);
        setAddress('Updating...');
        try {
            let loc = await Location.getCurrentPositionAsync({});
            setLocation(loc.coords);
            let geocode = await Location.reverseGeocodeAsync({
                latitude: loc.coords.latitude,
                longitude: loc.coords.longitude
            });
            if (geocode.length > 0) {
                const g = geocode[0];
                const addr = `${g.street || ''} ${g.name || ''}, ${g.city || ''}`;
                setAddress(addr.trim() || "Address not found");
            }
        } catch (error) {
            Alert.alert('Error', 'Could not refresh location');
        } finally {
            setIsLocationLoading(false);
        }
    };

    const pickMedia = async () => {
        try {
            const { status } = await ImagePicker.requestMediaLibraryPermissionsAsync();
            if (status !== 'granted') {
                Alert.alert('Permission needed', 'Sorry, we need gallery permissions to make this work!');
                return;
            }

            let result = await ImagePicker.launchImageLibraryAsync({
                mediaTypes: ImagePicker.MediaTypeOptions.All, // Reverting to MediaTypeOptions as MediaType is undefined
                allowsEditing: false,
                quality: 0.4,
            });

            if (!result.canceled) {
                setMedia(result.assets[0]);
            }
        } catch (error) {
            console.error("Error picking media:", error);
            Alert.alert("Error", "Failed to open gallery");
        }
    };

    const startCamera = async () => {
        if (!permission || !micPermission) return;

        if (!permission.granted) {
            const result = await requestPermission();
            if (!result.granted) {
                Alert.alert("Permission needed", "Camera permission is required.");
                return;
            }
        }

        if (!micPermission.granted) {
            const result = await requestMicPermission();
            if (!result.granted) {
                Alert.alert("Permission needed", "Microphone permission is required for video.");
                return;
            }
        }

        setIsCameraVisible(true);
    };

    const handleCapture = async () => {
        if (!cameraRef.current) return;

        if (cameraMode === 'picture') {
            try {
                const photo = await cameraRef.current.takePictureAsync({
                    quality: 0.4,
                    base64: false,
                    skipProcessing: true
                });
                setMedia(photo);
                setIsCameraVisible(false);
            } catch (error) {
                console.error("Capture failed:", error);
                Alert.alert("Error", "Failed to capture photo.");
            }
        } else {
            // Video Mode
            if (isRecording) {
                cameraRef.current.stopRecording();
                setIsRecording(false);
            } else {
                setIsRecording(true);
                try {
                    const video = await cameraRef.current.recordAsync({
                        maxDuration: 15, // Limit to 15 seconds
                    });
                    setMedia(video);
                    setIsCameraVisible(false);
                } catch (error) {
                    console.error("Recording failed:", error);
                    setIsRecording(false);
                    Alert.alert("Error", "Failed to record video.");
                }
            }
        }
    };

    const toggleCameraFacing = () => {
        setFacing(current => (current === 'back' ? 'front' : 'back'));
    };

    const handleSubmit = async () => {
        if (!category) return Alert.alert('Error', 'Please select an issue category');
        if (!description) return Alert.alert('Error', 'Please add a description');

        setIsLoading(true);
        try {
            const formData = new FormData();
            formData.append('title', `${category} Issue`);
            formData.append('description', description);
            formData.append('type', category);
            // Stringify location object for backend parsing
            formData.append('location', JSON.stringify({
                address: address,
                coordinates: location ? { lat: location.latitude, lng: location.longitude } : { lat: 0, lng: 0 }
            }));

            if (media) {
                const localUri = media.uri;
                const filename = localUri.split('/').pop();

                // Infer the type of the image
                const match = /\.(\w+)$/.exec(filename);
                let type = match ? `image/${match[1]}` : `image`;

                // Fix mime type for video
                if (localUri.endsWith('.mp4') || localUri.endsWith('.mov')) {
                    type = 'video/mp4';
                } else if (media.type === 'video') { // Fallback for general video type from picker
                    type = 'video/mp4'; // Default to mp4 if specific extension not found
                }


                formData.append('image', { uri: localUri, name: filename, type });
            }

            const token = await AsyncStorage.getItem('userToken');

            // Use fetch instead of axios for reliable file uploads
            const response = await fetch('http://10.145.135.40:5000/api/v1/issues', {
                method: 'POST',
                body: formData,
                headers: {
                    'Authorization': `Bearer ${token}`,
                    // Explicitly NOT setting Content-Type so fetch sets it with boundary
                },
            });

            const data = await response.json();

            if (response.ok && data.success) {
                Alert.alert('Success', 'Issue reported successfully!', [
                    { text: 'OK', onPress: () => navigation.navigate('Home') }
                ]);
                setDescription('');
                setCategory('');
                setMedia(null);
            } else {
                Alert.alert('Error', data.error || 'Failed to submit issue');
            }
        } catch (error) {
            console.error("Upload error:", error);
            Alert.alert('Error', 'Network request failed. Check your connection.');
        } finally {
            setIsLoading(false);
        }
    };

    if (!permission) return <View />;

    const isVideo = media && (media.type === 'video' || media.uri.endsWith('.mp4') || media.uri.endsWith('.mov'));

    return (
        <SafeAreaView style={styles.container}>
            {/* Header */}
            <View style={styles.header}>
                <TouchableOpacity onPress={() => navigation.goBack()} style={styles.backButton}>
                    <Ionicons name="arrow-back" size={24} color="#2d3436" />
                </TouchableOpacity>
                <Text style={styles.headerTitle}>Report a Civic Issue</Text>
                <Image
                    source={{ uri: 'https://randomuser.me/api/portraits/men/32.jpg' }}
                    style={styles.avatar}
                />
            </View>

            <ScrollView contentContainerStyle={styles.scrollContent} showsVerticalScrollIndicator={false}>

                {/* Visual Evidence Section */}
                <View style={styles.sectionHeader}>
                    <Text style={styles.sectionTitle}>Visual Evidence</Text>

                </View>

                <View style={styles.uploadContainer}>
                    {media ? (
                        <View style={styles.imagePreviewContainer}>
                            {isVideo ? (
                                <VideoPreview uri={media.uri} />
                            ) : (
                                <Image source={{ uri: media.uri }} style={styles.imagePreview} />
                            )}
                            <TouchableOpacity style={styles.removeImageButton} onPress={() => setMedia(null)}>
                                <Ionicons name="close-circle" size={24} color="#ff7675" />
                            </TouchableOpacity>
                        </View>
                    ) : (
                        <View style={styles.uploadPlaceholder}>
                            <View style={styles.cameraIconCircle}>
                                <Ionicons name="camera" size={30} color="#00D2D3" />
                                <Ionicons name="add" size={16} color="#00D2D3" style={styles.addIcon} />
                            </View>
                            <Text style={styles.uploadTitle}>Upload Evidence</Text>
                            <Text style={styles.uploadSubtitle}>Photos or short videos (max 15s)</Text>

                            <View style={styles.buttonRow}>
                                <TouchableOpacity style={[styles.addPhotosButton, { marginRight: 10, backgroundColor: '#fff', borderWidth: 1, borderColor: '#00D2D3' }]} onPress={startCamera}>
                                    <Ionicons name="camera" size={20} color="#00D2D3" style={{ marginRight: 5 }} />
                                    <Text style={[styles.addPhotosButtonText, { color: '#00D2D3' }]}>Camera</Text>
                                </TouchableOpacity>

                                <TouchableOpacity style={styles.addPhotosButton} onPress={pickMedia}>
                                    <Ionicons name="images" size={20} color="#fff" style={{ marginRight: 5 }} />
                                    <Text style={styles.addPhotosButtonText}>Gallery</Text>
                                </TouchableOpacity>
                            </View>
                        </View>
                    )}
                </View>

                {/* Details Section */}
                <Text style={styles.label}>Details</Text>

                <Text style={styles.subLabel}>Issue Type</Text>
                <TouchableOpacity style={styles.dropdownInput} onPress={() => setShowDropdown(!showDropdown)}>
                    <Text style={styles.dropdownText}>{category || 'Select issue category'}</Text>
                    <Ionicons name="chevron-down" size={20} color="#636e72" />
                </TouchableOpacity>

                {showDropdown && (
                    <View style={styles.dropdownList}>
                        {categories.map((cat) => (
                            <TouchableOpacity key={cat} style={styles.dropdownItem} onPress={() => { setCategory(cat); setShowDropdown(false); }}>
                                <Text style={styles.dropdownItemText}>{cat}</Text>
                            </TouchableOpacity>
                        ))}
                    </View>
                )}

                <Text style={styles.subLabel}>Description</Text>
                <TextInput
                    style={styles.textArea}
                    placeholder="Tell us more regarding the issue..."
                    placeholderTextColor="#b2bec3"
                    multiline
                    numberOfLines={4}
                    value={description}
                    onChangeText={setDescription}
                    textAlignVertical="top"
                />

                {/* Location Section */}
                <Text style={styles.label}>Location</Text>
                <View style={styles.mapPreviewCard}>
                    <Image
                        source={{ uri: 'https://staticmapmaker.com/img/google-placeholder.png' }}
                        style={styles.mapImage}
                    />
                    <View style={styles.mapOverlay}>
                        <View style={styles.locationPin}>
                            <View style={styles.locationPinInner} />
                        </View>
                    </View>
                    <View style={styles.locationAddressBar}>
                        <Ionicons name="location-sharp" size={18} color="#00D2D3" />
                        <Text style={styles.addressText} numberOfLines={1}>
                            {isLocationLoading ? 'Detecting location...' : address}
                        </Text>
                        <TouchableOpacity style={styles.changeButton} onPress={refreshLocation}>
                            {isLocationLoading ? (
                                <ActivityIndicator size="small" color="#00D2D3" />
                            ) : (
                                <Text style={styles.changeButtonText}>Update</Text>
                            )}
                        </TouchableOpacity>
                    </View>
                </View>

                {/* Bottom Padding for scroll */}
                <View style={{ height: 100 }} />

            </ScrollView>

            {/* Floating Action Button */}
            <View style={styles.footer}>
                <TouchableOpacity style={styles.submitButton} onPress={handleSubmit} disabled={isLoading || isLocationLoading}>
                    {isLoading ? (
                        <ActivityIndicator color="#fff" />
                    ) : (
                        <>
                            <Text style={styles.submitButtonText}>Report Now</Text>
                            <Ionicons name="paper-plane" size={20} color="#fff" style={{ marginLeft: 10 }} />
                        </>
                    )}
                </TouchableOpacity>
                <Text style={styles.secureText}>SECURE CIVIC SUBMISSION</Text>
            </View>

            {/* In-App Camera Modal */}
            <Modal
                animationType="slide"
                visible={isCameraVisible}
                onRequestClose={() => setIsCameraVisible(false)}
            >
                <View style={styles.cameraContainer}>
                    <CameraView
                        style={styles.camera}
                        facing={facing}
                        ref={cameraRef}
                        mode={cameraMode}
                    />

                    {/* Controls Overlay - Moved OUTSIDE CameraView */}
                    <View style={styles.cameraControlsOverlay}>
                        {/* Mode Switcher */}
                        <View style={styles.modeSwitcher}>
                            <TouchableOpacity onPress={() => setCameraMode('picture')}>
                                <Text style={[styles.modeText, cameraMode === 'picture' && styles.activeModeText]}>Photo</Text>
                            </TouchableOpacity>
                            <TouchableOpacity onPress={() => setCameraMode('video')} style={{ marginLeft: 20 }}>
                                <Text style={[styles.modeText, cameraMode === 'video' && styles.activeModeText]}>Video</Text>
                            </TouchableOpacity>
                        </View>

                        <View style={styles.cameraControls}>
                            <TouchableOpacity style={styles.cameraBtnSecondary} onPress={() => setIsCameraVisible(false)}>
                                <Ionicons name="close" size={24} color="#fff" />
                            </TouchableOpacity>

                            <TouchableOpacity
                                style={[
                                    styles.cameraBtnPrimary,
                                    cameraMode === 'video' && { borderColor: '#ff7675' }
                                ]}
                                onPress={handleCapture}
                            >
                                <View style={[
                                    styles.cameraBtnInner,
                                    cameraMode === 'video' && { backgroundColor: '#ff7675', borderRadius: isRecording ? 4 : 25, width: isRecording ? 24 : 50, height: isRecording ? 24 : 50 }
                                ]} />
                            </TouchableOpacity>

                            <TouchableOpacity style={styles.cameraBtnSecondary} onPress={toggleCameraFacing}>
                                <Ionicons name="camera-reverse" size={24} color="#fff" />
                            </TouchableOpacity>
                        </View>
                        {isRecording && (
                            <View style={styles.recordingIndicator}>
                                <View style={styles.recordingDot} />
                                <Text style={styles.recordingText}>Recording...</Text>
                            </View>
                        )}
                    </View>
                </View>
            </Modal>

        </SafeAreaView>
    );
};

const styles = StyleSheet.create({
    container: { flex: 1, backgroundColor: '#F7F9FC' },
    header: { flexDirection: 'row', alignItems: 'center', justifyContent: 'space-between', paddingHorizontal: 20, paddingVertical: 15 },
    backButton: { width: 40 },
    headerTitle: { fontSize: 18, fontWeight: 'bold', color: '#2d3436' },
    avatar: { width: 36, height: 36, borderRadius: 18, backgroundColor: '#dfe6e9' },
    scrollContent: { paddingHorizontal: 20 },
    sectionHeader: { flexDirection: 'row', justifyContent: 'space-between', alignItems: 'baseline', marginBottom: 10 },
    sectionTitle: { fontSize: 16, fontWeight: 'bold', color: '#2d3436' },
    uploadContainer: { backgroundColor: '#fff', borderRadius: 20, borderWidth: 1, borderColor: '#dfe6e9', borderStyle: 'dashed', marginBottom: 25, overflow: 'hidden' },
    uploadPlaceholder: { alignItems: 'center', padding: 30 },
    cameraIconCircle: { width: 60, height: 60, borderRadius: 30, backgroundColor: '#E6F7F8', alignItems: 'center', justifyContent: 'center', marginBottom: 15, position: 'relative' },
    addIcon: { position: 'absolute', top: 10, right: 12 },
    uploadTitle: { fontSize: 16, fontWeight: 'bold', color: '#2d3436', marginBottom: 5 },
    uploadSubtitle: { fontSize: 13, color: '#636e72', textAlign: 'center', marginBottom: 20, paddingHorizontal: 10 },
    addPhotosButton: { backgroundColor: '#00D2D3', paddingVertical: 12, paddingHorizontal: 20, borderRadius: 25, shadowColor: '#00D2D3', shadowOffset: { width: 0, height: 4 }, shadowOpacity: 0.3, shadowRadius: 8, elevation: 4, flexDirection: 'row', alignItems: 'center' },
    addPhotosButtonText: { color: '#fff', fontWeight: 'bold', fontSize: 14 },
    imagePreviewContainer: { width: '100%', height: 250, position: 'relative' },
    imagePreview: { width: '100%', height: '100%', resizeMode: 'cover' },
    removeImageButton: { position: 'absolute', top: 10, right: 10, backgroundColor: '#fff', borderRadius: 15 },
    label: { fontSize: 16, fontWeight: 'bold', color: '#2d3436', marginBottom: 15, marginTop: 5 },
    subLabel: { fontSize: 14, color: '#535c68', fontWeight: '500', marginBottom: 8 },
    dropdownInput: { backgroundColor: '#fff', borderWidth: 1, borderColor: '#dfe6e9', borderRadius: 15, paddingHorizontal: 15, paddingVertical: 14, flexDirection: 'row', justifyContent: 'space-between', alignItems: 'center', marginBottom: 20 },
    dropdownList: { backgroundColor: '#fff', borderWidth: 1, borderColor: '#dfe6e9', borderRadius: 15, marginTop: -15, marginBottom: 20, padding: 10 },
    dropdownItem: { paddingVertical: 10, borderBottomWidth: 1, borderBottomColor: '#f1f2f6' },
    dropdownItemText: { fontSize: 14, color: '#2d3436' },
    dropdownText: { fontSize: 14, color: '#2d3436' },
    textArea: { backgroundColor: '#fff', borderWidth: 1, borderColor: '#dfe6e9', borderRadius: 15, paddingHorizontal: 15, paddingVertical: 15, fontSize: 14, color: '#2d3436', minHeight: 120, marginBottom: 25 },
    mapPreviewCard: { height: 150, backgroundColor: '#dfe6e9', borderRadius: 15, overflow: 'hidden', position: 'relative', marginBottom: 10 },
    mapImage: { width: '100%', height: '100%', opacity: 0.8 },
    mapOverlay: { ...StyleSheet.absoluteFillObject, justifyContent: 'center', alignItems: 'center' },
    locationPin: { width: 30, height: 30, borderRadius: 15, backgroundColor: 'rgba(0, 210, 211, 0.3)', justifyContent: 'center', alignItems: 'center' },
    locationPinInner: { width: 14, height: 14, borderRadius: 7, backgroundColor: '#00D2D3', borderWidth: 2, borderColor: '#fff' },
    locationAddressBar: { position: 'absolute', bottom: 10, left: 10, right: 10, backgroundColor: '#fff', borderRadius: 10, flexDirection: 'row', alignItems: 'center', padding: 10, shadowColor: '#000', shadowOffset: { width: 0, height: 2 }, shadowOpacity: 0.1, shadowRadius: 4, elevation: 2 },
    addressText: { flex: 1, fontSize: 12, color: '#2d3436', marginLeft: 8, fontWeight: '500' },
    changeButton: { backgroundColor: '#E6F7F8', paddingHorizontal: 10, paddingVertical: 5, borderRadius: 8, minWidth: 50, alignItems: 'center' },
    changeButtonText: { color: '#00D2D3', fontSize: 10, fontWeight: 'bold' },
    footer: { position: 'absolute', bottom: 0, left: 0, right: 0, backgroundColor: 'transparent', padding: 20, alignItems: 'center', paddingBottom: 90 },
    submitButton: { backgroundColor: '#00D2D3', width: '100%', paddingVertical: 16, borderRadius: 25, flexDirection: 'row', justifyContent: 'center', alignItems: 'center', shadowColor: '#00D2D3', shadowOffset: { width: 0, height: 5 }, shadowOpacity: 0.3, shadowRadius: 10, elevation: 5, marginBottom: 10 },
    submitButtonText: { color: '#fff', fontSize: 16, fontWeight: 'bold' },
    secureText: { fontSize: 10, color: '#636e72', fontWeight: 'bold', letterSpacing: 1, textTransform: 'uppercase' },
    buttonRow: { flexDirection: 'row', justifyContent: 'center', alignItems: 'center', marginTop: 10 },
    cameraContainer: { flex: 1, backgroundColor: 'black' },
    camera: {
        flex: 1,
    },
    cameraControlsOverlay: {
        ...StyleSheet.absoluteFillObject,
        justifyContent: 'flex-end',
        zIndex: 10,
    },
    cameraControls: {
        flexDirection: 'row',
        justifyContent: 'space-around',
        alignItems: 'center',
        paddingBottom: 50,
        backgroundColor: 'rgba(0,0,0,0.3)',
        paddingTop: 20
    },
    cameraBtnPrimary: { width: 70, height: 70, borderRadius: 35, backgroundColor: 'rgba(255,255,255,0.3)', justifyContent: 'center', alignItems: 'center', borderWidth: 4, borderColor: '#fff' },
    cameraBtnInner: { width: 50, height: 50, borderRadius: 25, backgroundColor: '#fff' },
    cameraBtnSecondary: { width: 50, height: 50, borderRadius: 25, backgroundColor: 'rgba(0,0,0,0.5)', justifyContent: 'center', alignItems: 'center' },
    modeSwitcher: { position: 'absolute', top: 50, left: 0, right: 0, flexDirection: 'row', justifyContent: 'center', alignItems: 'center', zIndex: 10 },
    modeText: { color: 'rgba(255,255,255,0.6)', fontSize: 16, fontWeight: '600', padding: 10 },
    activeModeText: { color: '#fff', fontWeight: 'bold' },
    recordingIndicator: { position: 'absolute', top: 100, alignSelf: 'center', flexDirection: 'row', alignItems: 'center', backgroundColor: 'rgba(255,0,0,0.5)', padding: 10, borderRadius: 20 },
    recordingDot: { width: 10, height: 10, borderRadius: 5, backgroundColor: '#ff0000', marginRight: 8 },
    recordingText: { color: '#fff', fontWeight: 'bold' }

});

export default ReportScreen;
