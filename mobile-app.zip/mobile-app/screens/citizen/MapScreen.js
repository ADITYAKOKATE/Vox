import React, { useState, useEffect, useCallback, useRef } from 'react';
import { View, Text, StyleSheet, Dimensions, TouchableOpacity, Alert, ActivityIndicator, ScrollView, Image, Platform, Animated } from 'react-native';
import MapView, { Marker, PROVIDER_GOOGLE } from '../../components/NativeMap';
import * as Location from 'expo-location';
import { Ionicons } from '@expo/vector-icons';
import { useFocusEffect } from '@react-navigation/native';
import client from '../../api/client';
import { SafeAreaView } from 'react-native-safe-area-context';

const { width, height } = Dimensions.get('window');

const MapScreen = ({ navigation }) => {
    const [issues, setIssues] = useState([]);
    const [filteredIssues, setFilteredIssues] = useState([]);
    const [location, setLocation] = useState(null);
    const [loading, setLoading] = useState(true);
    const [selectedCategory, setSelectedCategory] = useState('All');
    const [selectedIssue, setSelectedIssue] = useState(null);
    const mapRef = useRef(null);
    const slideAnim = useRef(new Animated.Value(300)).current; // For bottom card

    const categories = ['All', 'Pothole', 'Streetlight', 'Garbage', 'Water', 'Noise', 'Traffic', 'Other'];

    // Map categories to Icons and Colors
    const getCategoryStyles = (type) => {
        switch (type) {
            case 'Pothole': return { icon: 'warning', color: '#ff7675', bg: '#ffeaa7' };
            case 'Streetlight': return { icon: 'bulb', color: '#fdcb6e', bg: '#fffce7' };
            case 'Garbage': return { icon: 'trash', color: '#d63031', bg: '#fad390' };
            case 'Water': return { icon: 'water', color: '#0984e3', bg: '#dff9fb' };
            case 'Noise': return { icon: 'volume-high', color: '#6c5ce7', bg: '#a29bfe' };
            case 'Traffic': return { icon: 'car', color: '#e17055', bg: '#fab1a0' };
            case 'Other': return { icon: 'help-circle', color: '#636e72', bg: '#dfe6e9' };
            default: return { icon: 'location', color: '#00D2D3', bg: '#E6F7F8' };
        }
    };

    const fetchIssues = async () => {
        try {
            const res = await client.get('/issues');
            if (res.data.success) {
                setIssues(res.data.data);
                filterIssues(res.data.data, selectedCategory);
            }
        } catch (error) {
            console.log('Error fetching map issues:', error);
        }
    };

    const filterIssues = (allIssues, category) => {
        if (category === 'All') {
            setFilteredIssues(allIssues);
        } else {
            const filtered = allIssues.filter(issue => issue.type === category);
            setFilteredIssues(filtered);
        }
    };

    const handleCategorySelect = (category) => {
        setSelectedCategory(category);
        filterIssues(issues, category);
        setSelectedIssue(null); // Deselect on filter change
    };

    const handleMarkerPress = (issue) => {
        setSelectedIssue(issue);
        // Animate card up
        Animated.spring(slideAnim, {
            toValue: 0,
            useNativeDriver: true,
        }).start();

        // Optional: Center map on marker slightly offset to fit card
        if (mapRef.current && issue.location?.coordinates) {
            mapRef.current.animateToRegion({
                latitude: issue.location.coordinates.lat - 0.002, // Offset for card
                longitude: issue.location.coordinates.lng,
                latitudeDelta: 0.005,
                longitudeDelta: 0.005,
            }, 500);
        }
    };

    const closeCard = () => {
        Animated.timing(slideAnim, {
            toValue: 300,
            duration: 250,
            useNativeDriver: true,
        }).start(() => setSelectedIssue(null));
    };

    const getUserLocation = async () => {
        try {
            let { status } = await Location.requestForegroundPermissionsAsync();
            if (status !== 'granted') {
                return;
            }
            let loc = await Location.getCurrentPositionAsync({});
            const userRegion = {
                latitude: loc.coords.latitude,
                longitude: loc.coords.longitude,
                latitudeDelta: 0.0122,
                longitudeDelta: 0.0051,
            };
            setLocation(userRegion);
            if (mapRef.current) mapRef.current.animateToRegion(userRegion, 1000);
        } catch (error) {
            console.log("Error getting location", error);
        } finally {
            setLoading(false);
        }
    };

    useEffect(() => {
        getUserLocation();
    }, []);

    useFocusEffect(
        useCallback(() => {
            fetchIssues();
        }, [])
    );

    const recenterMap = () => {
        if (location && mapRef.current) {
            mapRef.current.animateToRegion(location, 1000);
        } else {
            getUserLocation();
        }
    };

    if (loading) {
        return (
            <View style={[styles.container, { justifyContent: 'center', alignItems: 'center' }]}>
                <ActivityIndicator size="large" color="#00D2D3" />
            </View>
        );
    }

    return (
        <View style={styles.container}>
            <MapView
                ref={mapRef}
                style={styles.map}
                initialRegion={location || { latitude: 19.0760, longitude: 72.8777, latitudeDelta: 0.09, longitudeDelta: 0.04 }}
                showsUserLocation={true}
                showsMyLocationButton={false}
                onPress={closeCard} // Close card when clicking map background
            >
                {filteredIssues.map((issue) => {
                    const lat = parseFloat(issue.location?.coordinates?.lat);
                    const lng = parseFloat(issue.location?.coordinates?.lng);
                    const { icon, color, bg } = getCategoryStyles(issue.type);

                    if (!isNaN(lat) && !isNaN(lng)) {
                        return (
                            <Marker
                                key={issue._id}
                                coordinate={{ latitude: lat, longitude: lng }}
                                onPress={() => handleMarkerPress(issue)}
                            >
                                <View style={[styles.customMarker, { backgroundColor: bg, borderColor: color }]}>
                                    <Ionicons name={icon} size={16} color={color} />
                                </View>
                            </Marker>
                        );
                    }
                    return null;
                })}
            </MapView>

            {/* Top Floating Bar */}
            <SafeAreaView style={styles.topContainer} pointerEvents="box-none">
                <View style={styles.searchBar}>
                    <Ionicons name="search" size={20} color="#2d3436" />
                    <Text style={styles.searchText}>Search area or ID...</Text>

                </View>

                {/* Filter Chips */}
                <View style={styles.filterContainer}>
                    <ScrollView horizontal showsHorizontalScrollIndicator={false} contentContainerStyle={styles.filterScroll}>
                        {categories.map((cat) => {
                            const { color } = getCategoryStyles(cat);
                            const isActive = selectedCategory === cat;
                            return (
                                <TouchableOpacity
                                    key={cat}
                                    style={[
                                        styles.filterChip,
                                        isActive && { backgroundColor: cat === 'All' ? '#2d3436' : color, borderColor: cat === 'All' ? '#2d3436' : color }
                                    ]}
                                    onPress={() => handleCategorySelect(cat)}
                                >
                                    {cat !== 'All' && <View style={[styles.dot, { backgroundColor: isActive ? '#fff' : color }]} />}
                                    <Text style={[styles.filterText, isActive && styles.activeFilterText]}>
                                        {cat}
                                    </Text>
                                </TouchableOpacity>
                            );
                        })}
                    </ScrollView>
                </View>
            </SafeAreaView>

            {/* Side Controls */}
            <View style={styles.sideControls}>
                <TouchableOpacity style={styles.controlButton} onPress={() => { }}>
                    <Ionicons name="add" size={24} color="#2d3436" />
                </TouchableOpacity>
                <TouchableOpacity style={styles.controlButton} onPress={() => { }}>
                    <Ionicons name="remove" size={24} color="#2d3436" />
                </TouchableOpacity>
                <TouchableOpacity style={[styles.controlButton, { marginTop: 10 }]} onPress={recenterMap}>
                    <Ionicons name="locate" size={24} color="#00D2D3" />
                </TouchableOpacity>
            </View>

            {/* Bottom Info Card */}
            {selectedIssue && (
                <Animated.View style={[styles.bottomCard, { transform: [{ translateY: slideAnim }] }]}>
                    <TouchableOpacity style={styles.cardContent} onPress={() => navigation.navigate('IssueDetails', { issue: selectedIssue })}>
                        <View style={styles.cardHeader}>
                            <View style={[styles.categoryTag, { backgroundColor: getCategoryStyles(selectedIssue.type).bg }]}>
                                <Text style={[styles.categoryText, { color: getCategoryStyles(selectedIssue.type).color }]}>
                                    {selectedIssue.type.toUpperCase()}
                                </Text>
                            </View>
                            <Text style={styles.cardStatus}>{selectedIssue.status}</Text>
                        </View>

                        <View style={styles.cardBody}>
                            <View style={styles.cardTextContainer}>
                                <Text style={styles.cardTitle} numberOfLines={1}>{selectedIssue.title}</Text>
                                <View style={styles.locationRow}>
                                    <Ionicons name="location-sharp" size={14} color="#636e72" />
                                    <Text style={styles.cardAddress} numberOfLines={1}>
                                        {selectedIssue.location?.address || 'Unknown layout'}
                                    </Text>
                                </View>
                            </View>
                            {selectedIssue.image && (
                                <Image source={{ uri: selectedIssue.image }} style={styles.cardImage} />
                            )}
                        </View>

                        <TouchableOpacity
                            style={styles.actionButton}
                            onPress={() => navigation.navigate('IssueDetails', { issue: selectedIssue })}
                        >
                            <Text style={styles.actionButtonText}>View Details</Text>
                            <Ionicons name="arrow-forward" size={16} color="#fff" />
                        </TouchableOpacity>
                    </TouchableOpacity>
                </Animated.View>
            )}
        </View>
    );
};

const styles = StyleSheet.create({
    container: {
        flex: 1,
        backgroundColor: '#fff',
    },
    map: {
        width: width,
        height: height,
    },
    customMarker: {
        width: 36,
        height: 36,
        borderRadius: 18,
        justifyContent: 'center',
        alignItems: 'center',
        borderWidth: 2,
        shadowColor: '#000',
        shadowOffset: { width: 0, height: 2 },
        shadowOpacity: 0.2,
        shadowRadius: 3,
        elevation: 4,
    },
    topContainer: {
        position: 'absolute',
        top: 0,
        left: 0,
        right: 0,
        paddingHorizontal: 15,
        paddingTop: 10,
    },
    searchBar: {
        flexDirection: 'row',
        alignItems: 'center',
        backgroundColor: '#fff',
        borderRadius: 12,
        paddingHorizontal: 15,
        paddingVertical: 12,
        shadowColor: '#000',
        shadowOffset: { width: 0, height: 2 },
        shadowOpacity: 0.1,
        shadowRadius: 8,
        elevation: 5,
        marginBottom: 10,
    },
    searchText: {
        flex: 1,
        marginLeft: 10,
        fontSize: 16,
        color: '#2d3436',
    },
    filterContainer: {
        height: 50,
    },
    filterScroll: {
        paddingRight: 15,
    },
    filterChip: {
        flexDirection: 'row',
        alignItems: 'center',
        paddingHorizontal: 14,
        paddingVertical: 8,
        backgroundColor: '#fff',
        borderRadius: 20,
        marginRight: 8,
        shadowColor: '#000',
        shadowOffset: { width: 0, height: 1 },
        shadowOpacity: 0.1,
        shadowRadius: 2,
        elevation: 3,
    },
    dot: {
        width: 8,
        height: 8,
        borderRadius: 4,
        marginRight: 6,
    },
    filterText: {
        fontSize: 13,
        fontWeight: '600',
        color: '#2d3436',
    },
    activeFilterText: {
        color: '#fff',
    },
    sideControls: {
        position: 'absolute',
        right: 15,
        top: '40%',
    },
    controlButton: {
        width: 44,
        height: 44,
        borderRadius: 12,
        backgroundColor: '#fff',
        justifyContent: 'center',
        alignItems: 'center',
        marginBottom: 10,
        shadowColor: '#000',
        shadowOffset: { width: 0, height: 2 },
        shadowOpacity: 0.1,
        shadowRadius: 4,
        elevation: 3,
    },
    bottomCard: {
        position: 'absolute',
        bottom: 90, // Above bottom tab bar
        left: 15,
        right: 15,
        backgroundColor: '#fff',
        borderRadius: 20,
        shadowColor: '#000',
        shadowOffset: { width: 0, height: 5 },
        shadowOpacity: 0.2,
        shadowRadius: 10,
        elevation: 10,
        padding: 5,
    },
    cardContent: {
        padding: 15,
    },
    cardHeader: {
        flexDirection: 'row',
        justifyContent: 'space-between',
        alignItems: 'center',
        marginBottom: 10,
    },
    categoryTag: {
        paddingHorizontal: 8,
        paddingVertical: 4,
        borderRadius: 6,
    },
    categoryText: {
        fontSize: 10,
        fontWeight: 'bold',
        letterSpacing: 0.5,
    },
    cardStatus: {
        fontSize: 12,
        color: '#b2bec3',
        fontWeight: '600',
    },
    cardBody: {
        flexDirection: 'row',
        justifyContent: 'space-between',
        alignItems: 'flex-start',
        marginBottom: 15,
    },
    cardTextContainer: {
        flex: 1,
        paddingRight: 10,
    },
    cardTitle: {
        fontSize: 18,
        fontWeight: 'bold',
        color: '#2d3436',
        marginBottom: 5,
    },
    locationRow: {
        flexDirection: 'row',
        alignItems: 'center',
    },
    cardAddress: {
        fontSize: 13,
        color: '#636e72',
        marginLeft: 4,
    },
    cardImage: {
        width: 60,
        height: 60,
        borderRadius: 10,
        backgroundColor: '#dfe6e9',
    },
    actionButton: {
        backgroundColor: '#00D2D3',
        flexDirection: 'row',
        justifyContent: 'center',
        alignItems: 'center',
        paddingVertical: 12,
        borderRadius: 12,
    },
    actionButtonText: {
        color: '#fff',
        fontWeight: 'bold',
        marginRight: 8,
    }
});

export default MapScreen;
