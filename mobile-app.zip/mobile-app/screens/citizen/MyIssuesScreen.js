import React, { useState, useEffect, useCallback } from 'react';
import { View, Text, StyleSheet, FlatList, Image, TouchableOpacity, ActivityIndicator, RefreshControl } from 'react-native';
import { SafeAreaView } from 'react-native-safe-area-context';
import { Ionicons } from '@expo/vector-icons';
import { useFocusEffect } from '@react-navigation/native';
import client from '../../api/client';

const MyIssuesScreen = ({ navigation }) => {
    const [issues, setIssues] = useState([]);
    const [loading, setLoading] = useState(true);
    const [refreshing, setRefreshing] = useState(false);

    const fetchIssues = async () => {
        try {
            const res = await client.get('/issues/my-issues');
            if (res.data.success) {
                setIssues(res.data.data);
            }
        } catch (error) {
            console.log('Error fetching my issues:', error);
        } finally {
            setLoading(false);
            setRefreshing(false);
        }
    };

    useFocusEffect(
        useCallback(() => {
            fetchIssues();
        }, [])
    );

    const onRefresh = () => {
        setRefreshing(true);
        fetchIssues();
    };

    const getStatusColor = (status) => {
        switch (status) {
            case 'Resolved': return '#1dd1a1';
            case 'In Progress': return '#54a0ff';
            case 'Rejected': return '#ff6b6b';
            default: return '#feca57'; // Pending
        }
    };

    const renderItem = ({ item }) => {
        // Handle image URL - specific for backend placeholder or real URL
        let imageSource = { uri: 'https://via.placeholder.com/150' };
        if (item.image && item.image.startsWith('http')) {
            imageSource = { uri: item.image };
        } else if (item.image) {
            // If image is just filename
            // imageSource = { uri: `${baseURL}/uploads/${item.image}` };
            imageSource = { uri: 'https://via.placeholder.com/150' };
        }

        const statusColor = getStatusColor(item.status);

        return (
            <View style={styles.card}>
                <Image source={imageSource} style={styles.image} />
                <View style={styles.content}>
                    <View style={styles.header}>
                        <View style={[styles.statusBadge, { backgroundColor: statusColor + '20' }]}>
                            <Text style={[styles.statusText, { color: statusColor }]}>{item.status.toUpperCase()}</Text>
                        </View>
                        <Text style={styles.date}>{new Date(item.createdAt).toLocaleDateString()}</Text>
                    </View>
                    <Text style={styles.title} numberOfLines={1}>{item.title}</Text>

                    <TouchableOpacity style={styles.button} onPress={() => navigation.navigate('IssueDetails', { issue: item })}>
                        <Text style={styles.buttonText}>View Details</Text>
                        <Ionicons name="chevron-forward" size={16} color="#0984e3" />
                    </TouchableOpacity>
                </View>
            </View>
        );
    };

    if (loading && !refreshing) {
        return (
            <SafeAreaView style={[styles.container, { justifyContent: 'center', alignItems: 'center' }]}>
                <ActivityIndicator size="large" color="#00D2D3" />
            </SafeAreaView>
        );
    }

    return (
        <SafeAreaView style={styles.container}>
            <Text style={styles.screenTitle}>My Issues</Text>

            {issues.length === 0 ? (
                <View style={styles.emptyContainer}>
                    <Ionicons name="document-text-outline" size={60} color="#b2bec3" />
                    <Text style={styles.emptyText}>No issues reported yet.</Text>
                </View>
            ) : (
                <FlatList
                    data={issues}
                    renderItem={renderItem}
                    keyExtractor={item => item._id}
                    contentContainerStyle={styles.listContent}
                    showsVerticalScrollIndicator={false}
                    refreshControl={
                        <RefreshControl refreshing={refreshing} onRefresh={onRefresh} colors={['#00D2D3']} />
                    }
                />
            )}
        </SafeAreaView>
    );
};

const styles = StyleSheet.create({
    container: {
        flex: 1,
        backgroundColor: '#F7F9FC',
        paddingHorizontal: 20,
    },
    screenTitle: {
        fontSize: 24,
        fontWeight: 'bold',
        color: '#2d3436',
        marginVertical: 20,
    },
    listContent: {
        paddingBottom: 100,
    },
    card: {
        backgroundColor: '#fff',
        borderRadius: 15,
        marginBottom: 20,
        overflow: 'hidden',
        shadowColor: '#000',
        shadowOffset: { width: 0, height: 2 },
        shadowOpacity: 0.05,
        shadowRadius: 5,
        elevation: 2,
        flexDirection: 'row',
        height: 120,
    },
    image: {
        width: 100,
        height: '100%',
        backgroundColor: '#dfe6e9'
    },
    content: {
        flex: 1,
        padding: 12,
        justifyContent: 'space-between',
    },
    header: {
        flexDirection: 'column',
        alignItems: 'flex-start',
    },
    statusBadge: {
        paddingHorizontal: 8,
        paddingVertical: 4,
        borderRadius: 8,
        marginBottom: 5,
    },
    statusText: {
        fontSize: 10,
        fontWeight: 'bold',
    },
    date: {
        fontSize: 10,
        color: '#b2bec3',
    },
    title: {
        fontSize: 16,
        fontWeight: 'bold',
        color: '#2d3436',
    },
    button: {
        flexDirection: 'row',
        alignItems: 'center',
    },
    buttonText: {
        fontSize: 12,
        color: '#0984e3',
        fontWeight: '600',
        marginRight: 4,
    },
    emptyContainer: {
        flex: 1,
        justifyContent: 'center',
        alignItems: 'center',
        marginTop: 100
    },
    emptyText: {
        marginTop: 20,
        fontSize: 16,
        color: '#b2bec3'
    }
});

export default MyIssuesScreen;
