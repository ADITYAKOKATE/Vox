import React, { useState, useEffect } from 'react';
import { View, Text, StyleSheet, ScrollView, TouchableOpacity, Image, Switch, Alert, Modal, TextInput, Linking } from 'react-native';
import { SafeAreaView } from 'react-native-safe-area-context';
import { Ionicons } from '@expo/vector-icons';
import AsyncStorage from '@react-native-async-storage/async-storage';
import client from '../../api/client';

const SettingsScreen = ({ navigation }) => {
    const [user, setUser] = useState({
        name: 'Loading...',
        email: 'loading...',
        role: 'CITIZEN'
    });
    const [notificationsEnabled, setNotificationsEnabled] = useState(true);
    const [theme, setTheme] = useState('System'); // 'System', 'Light', 'Dark'
    const [editModalVisible, setEditModalVisible] = useState(false);
    const [newName, setNewName] = useState('');

    const loadProfile = async () => {
        try {
            const userInfo = await AsyncStorage.getItem('userInfo');
            const savedTheme = await AsyncStorage.getItem('appTheme');
            const savedNotifs = await AsyncStorage.getItem('notificationsEnabled');

            if (userInfo) {
                const parsedUser = JSON.parse(userInfo);
                setUser(parsedUser);
                setNewName(parsedUser.name);
            }
            if (savedTheme) setTheme(savedTheme);
            if (savedNotifs !== null) setNotificationsEnabled(JSON.parse(savedNotifs));
        } catch (e) {
            console.error('Failed to load user info');
        }
    };

    useEffect(() => {
        loadProfile();
    }, []);

    const toggleNotifications = async () => {
        const newValue = !notificationsEnabled;
        setNotificationsEnabled(newValue);
        await AsyncStorage.setItem('notificationsEnabled', JSON.stringify(newValue));
    };

    const changeTheme = async (newTheme) => {
        setTheme(newTheme);
        await AsyncStorage.setItem('appTheme', newTheme);
    };

    const handleUpdateProfile = async () => {
        if (!newName.trim()) return;

        // Optimistic update
        const updatedUser = { ...user, name: newName };
        setUser(updatedUser);
        await AsyncStorage.setItem('userInfo', JSON.stringify(updatedUser)); // Update local storage
        setEditModalVisible(false);

        // Here you would typically call backend API to update profile
        // await client.put('/auth/updatedetails', { name: newName });
        Alert.alert("Success", "Profile updated successfully!");
    };

    const handleLogout = async () => {
        Alert.alert(
            "Sign Out",
            "Are you sure you want to sign out?",
            [
                { text: "Cancel", style: "cancel" },
                {
                    text: "Sign Out", style: "destructive", onPress: async () => {
                        await AsyncStorage.clear(); // Clear all data
                        navigation.reset({
                            index: 0,
                            routes: [{ name: 'Login' }],
                        });
                    }
                }
            ]
        );
    };

    const openPrivacyPolicy = () => {
        Linking.openURL('https://www.google.com'); // Placeholder link
    };

    return (
        <SafeAreaView style={styles.container}>
            <View style={styles.header}>
                <TouchableOpacity onPress={() => navigation.goBack()} style={styles.backButton}>
                    <Ionicons name="chevron-back" size={28} color="#2d3436" />
                </TouchableOpacity>
                <Text style={styles.headerTitle}>Settings</Text>
                <View style={{ width: 28 }} />
            </View>

            <ScrollView contentContainerStyle={styles.scrollContent} showsVerticalScrollIndicator={false}>

                {/* Profile Section */}
                <View style={styles.profileSection}>
                    <View style={styles.imageContainer}>
                        <Image
                            source={{ uri: 'https://randomuser.me/api/portraits/women/44.jpg' }}
                            style={styles.avatar}
                        />
                        <View style={styles.badge}>
                            <Ionicons name="shield-checkmark" size={12} color="#fff" />
                        </View>
                    </View>
                    <Text style={styles.userName}>{user.name}</Text>
                    <View style={styles.userRoleContainer}>
                        <Text style={styles.userRole}>{user.role}</Text>
                        <Text style={styles.dot}>•</Text>
                        <Text style={styles.userEmail}>{user.email}</Text>
                    </View>
                </View>

                {/* Account & Security */}
                <Text style={styles.sectionHeader}>ACCOUNT & SECURITY</Text>
                <View style={styles.card}>
                    <TouchableOpacity style={styles.settingItem} onPress={() => setEditModalVisible(true)}>
                        <View style={[styles.iconBox, { backgroundColor: '#E6F7F8' }]}>
                            <Ionicons name="person" size={20} color="#00D2D3" />
                        </View>
                        <Text style={styles.settingText}>Edit Profile Name</Text>
                        <Ionicons name="create-outline" size={20} color="#b2bec3" />
                    </TouchableOpacity>

                    <View style={styles.separator} />

                    <View style={styles.settingItem}>
                        <View style={[styles.iconBox, { backgroundColor: '#E6F7F8' }]}>
                            <Ionicons name="notifications" size={20} color="#00D2D3" />
                        </View>
                        <Text style={styles.settingText}>Notifications</Text>
                        <Switch
                            value={notificationsEnabled}
                            onValueChange={toggleNotifications}
                            trackColor={{ false: "#dfe6e9", true: "#00D2D3" }}
                            thumbColor={"#fff"}
                        />
                    </View>
                </View>

                {/* Preferences */}
                <Text style={styles.sectionHeader}>PREFERENCES</Text>
                <View style={styles.card}>
                    <View style={styles.settingItem}>
                        <View style={[styles.iconBox, { backgroundColor: '#E6F7F8' }]}>
                            <Ionicons name="contrast" size={20} color="#00D2D3" />
                        </View>
                        <View style={{ flex: 1 }}>
                            <Text style={styles.settingText}>App Theme</Text>
                            <Text style={styles.settingSubText}>{theme} preference active</Text>
                        </View>

                        <View style={styles.themeToggleBackground}>
                            {['System', 'Light', 'Dark'].map((t) => (
                                <TouchableOpacity
                                    key={t}
                                    style={[styles.themeToggleOption, theme === t && styles.activeThemeOption]}
                                    onPress={() => changeTheme(t)}
                                >
                                    <Text style={[styles.themeOptionText, theme === t && styles.activeThemeText]}>{t}</Text>
                                </TouchableOpacity>
                            ))}
                        </View>
                    </View>

                    <View style={styles.separator} />

                    <TouchableOpacity style={styles.settingItem} onPress={openPrivacyPolicy}>
                        <View style={[styles.iconBox, { backgroundColor: '#E6F7F8' }]}>
                            <Ionicons name="shield-half" size={20} color="#00D2D3" />
                        </View>
                        <Text style={styles.settingText}>Privacy Policy</Text>
                        <Ionicons name="open-outline" size={20} color="#b2bec3" />
                    </TouchableOpacity>
                </View>

                {/* Logout */}
                <TouchableOpacity style={styles.logoutButton} onPress={handleLogout}>
                    <Ionicons name="log-out-outline" size={20} color="#ff7675" style={{ marginRight: 10 }} />
                    <Text style={styles.logoutText}>Sign Out</Text>
                </TouchableOpacity>

                <Text style={styles.versionText}>CivicConnect v2.4.12 • Built for Metro City</Text>

                <View style={{ height: 100 }} />

            </ScrollView>

            {/* Edit Profile Modal */}
            <Modal
                animationType="slide"
                transparent={true}
                visible={editModalVisible}
                onRequestClose={() => setEditModalVisible(false)}
            >
                <View style={styles.modalOverlay}>
                    <View style={styles.modalContainer}>
                        <Text style={styles.modalTitle}>Update Profile</Text>
                        <Text style={styles.modalSubtitle}>Enter your new display name</Text>

                        <TextInput
                            style={styles.modalInput}
                            value={newName}
                            onChangeText={setNewName}
                            placeholder="Full Name"
                            autoFocus
                        />

                        <View style={styles.modalButtons}>
                            <TouchableOpacity style={styles.modalCancel} onPress={() => setEditModalVisible(false)}>
                                <Text style={styles.modalCancelText}>Cancel</Text>
                            </TouchableOpacity>
                            <TouchableOpacity style={styles.modalSave} onPress={handleUpdateProfile}>
                                <Text style={styles.modalSaveText}>Save</Text>
                            </TouchableOpacity>
                        </View>
                    </View>
                </View>
            </Modal>

        </SafeAreaView>
    );
};

const styles = StyleSheet.create({
    container: {
        flex: 1,
        backgroundColor: '#F7F9FC',
    },
    header: {
        flexDirection: 'row',
        alignItems: 'center',
        justifyContent: 'space-between',
        paddingHorizontal: 20,
        paddingVertical: 15,
    },
    headerTitle: {
        fontSize: 18,
        fontWeight: 'bold',
        color: '#2d3436',
    },
    backButton: {
        padding: 5,
        marginLeft: -5
    },
    scrollContent: {
        paddingHorizontal: 20,
        paddingTop: 10,
    },
    profileSection: {
        alignItems: 'center',
        marginBottom: 30,
    },
    imageContainer: {
        position: 'relative',
        marginBottom: 15,
    },
    avatar: {
        width: 100,
        height: 100,
        borderRadius: 50,
        backgroundColor: '#dfe6e9',
        borderWidth: 4,
        borderColor: '#fff',
        shadowColor: '#000',
        shadowOffset: { width: 0, height: 10 },
        shadowOpacity: 0.1,
        shadowRadius: 10,
    },
    badge: {
        position: 'absolute',
        bottom: 0,
        right: 5,
        backgroundColor: '#00D2D3',
        width: 28,
        height: 28,
        borderRadius: 14,
        justifyContent: 'center',
        alignItems: 'center',
        borderWidth: 3,
        borderColor: '#fff',
    },
    userName: {
        fontSize: 22,
        fontWeight: 'bold',
        color: '#2d3436',
        marginBottom: 5,
    },
    userRoleContainer: {
        flexDirection: 'row',
        alignItems: 'center',
    },
    userRole: {
        fontSize: 13,
        color: '#00D2D3',
        fontWeight: 'bold',
        letterSpacing: 0.5,
    },
    dot: {
        marginHorizontal: 8,
        color: '#b2bec3',
    },
    userEmail: {
        fontSize: 13,
        color: '#636e72',
    },
    sectionHeader: {
        fontSize: 12,
        fontWeight: 'bold',
        color: '#2d3436',
        marginBottom: 10,
        marginTop: 10,
        letterSpacing: 1.2,
    },
    card: {
        backgroundColor: '#fff',
        borderRadius: 20,
        paddingHorizontal: 15,
        paddingVertical: 5,
        marginBottom: 20,
        shadowColor: '#000',
        shadowOffset: { width: 0, height: 2 },
        shadowOpacity: 0.05,
        shadowRadius: 5,
        elevation: 2,
    },
    settingItem: {
        flexDirection: 'row',
        alignItems: 'center',
        paddingVertical: 15,
    },
    separator: {
        height: 1,
        backgroundColor: '#f1f2f6',
        marginLeft: 55,
    },
    iconBox: {
        width: 40,
        height: 40,
        borderRadius: 20,
        justifyContent: 'center',
        alignItems: 'center',
        marginRight: 15,
    },
    settingText: {
        flex: 1,
        fontSize: 16,
        color: '#2d3436',
        fontWeight: '500',
    },
    settingSubText: {
        fontSize: 12,
        color: '#b2bec3',
        marginTop: 2,
    },
    themeToggleBackground: {
        flexDirection: 'row',
        backgroundColor: '#F1F2F6',
        borderRadius: 15,
        padding: 2,
    },
    themeToggleOption: {
        paddingVertical: 6,
        paddingHorizontal: 12,
        borderRadius: 13,
    },
    activeThemeOption: {
        backgroundColor: '#fff',
        shadowColor: '#000',
        shadowOffset: { width: 0, height: 1 },
        shadowOpacity: 0.1,
        shadowRadius: 1,
        elevation: 2,
    },
    themeOptionText: {
        fontSize: 12,
        color: '#b2bec3',
        fontWeight: '600',
    },
    activeThemeText: {
        color: '#00D2D3',
        fontWeight: 'bold',
    },
    logoutButton: {
        backgroundColor: '#FFF0F0',
        borderRadius: 20,
        paddingVertical: 15,
        flexDirection: 'row',
        justifyContent: 'center',
        alignItems: 'center',
        marginBottom: 15,
        marginTop: 10,
        borderWidth: 1,
        borderColor: '#ffcece',
    },
    logoutText: {
        color: '#ff7675',
        fontWeight: 'bold',
        fontSize: 16,
    },
    versionText: {
        textAlign: 'center',
        color: '#b2bec3',
        fontSize: 12,
        marginBottom: 20,
    },
    // Modal Styles
    modalOverlay: {
        flex: 1,
        backgroundColor: 'rgba(0,0,0,0.5)',
        justifyContent: 'center',
        alignItems: 'center',
    },
    modalContainer: {
        width: '85%',
        backgroundColor: '#fff',
        borderRadius: 20,
        padding: 20,
        alignItems: 'center',
        shadowColor: '#000',
        shadowOffset: { width: 0, height: 10 },
        shadowOpacity: 0.2,
        shadowRadius: 20,
        elevation: 10,
    },
    modalTitle: {
        fontSize: 20,
        fontWeight: 'bold',
        color: '#2d3436',
        marginBottom: 10,
    },
    modalSubtitle: {
        fontSize: 14,
        color: '#636e72',
        marginBottom: 20,
    },
    modalInput: {
        width: '100%',
        backgroundColor: '#F1F2F6',
        padding: 15,
        borderRadius: 12,
        fontSize: 16,
        color: '#2d3436',
        marginBottom: 20,
    },
    modalButtons: {
        flexDirection: 'row',
        justifyContent: 'space-between',
        width: '100%',
    },
    modalCancel: {
        flex: 1,
        padding: 15,
        borderRadius: 12,
        backgroundColor: '#f1f2f6',
        marginRight: 10,
        alignItems: 'center',
    },
    modalCancelText: {
        color: '#636e72',
        fontWeight: 'bold',
    },
    modalSave: {
        flex: 1,
        padding: 15,
        borderRadius: 12,
        backgroundColor: '#00D2D3',
        marginLeft: 10,
        alignItems: 'center',
    },
    modalSaveText: {
        color: '#fff',
        fontWeight: 'bold',
    },
});

export default SettingsScreen;
