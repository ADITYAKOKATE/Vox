import React, { useState, useEffect, useCallback } from 'react';
import { View, Text, StyleSheet, ScrollView, Image, TouchableOpacity, Dimensions, ActivityIndicator } from 'react-native';
import { SafeAreaView } from 'react-native-safe-area-context';
import { Ionicons } from '@expo/vector-icons';
import { LinearGradient } from 'expo-linear-gradient';
import { useFocusEffect } from '@react-navigation/native';
import AsyncStorage from '@react-native-async-storage/async-storage';
import client from '../../api/client';

const { width } = Dimensions.get('window');

const HomeScreen = ({ navigation }) => {
    const [stats, setStats] = useState({ total: 0, resolved: 0, pending: 0 });
    const [userName, setUserName] = useState('Citizen');
    const [loading, setLoading] = useState(true);

    const fetchDashboardData = async () => {
        try {
            // Get user name
            const userInfo = await AsyncStorage.getItem('userInfo');
            if (userInfo) {
                setUserName(JSON.parse(userInfo).name);
            }

            // Get stats
            const res = await client.get('/issues/stats');
            if (res.data.success) {
                setStats(res.data.data);
            }
        } catch (error) {
            console.log('Error fetching dashboard data:', error);
        } finally {
            setLoading(false);
        }
    };

    useFocusEffect(
        useCallback(() => {
            fetchDashboardData();
        }, [])
    );

    return (
        <SafeAreaView style={styles.container}>
            <ScrollView contentContainerStyle={styles.scrollContent} showsVerticalScrollIndicator={false}>

                {/* Header Section */}
                <View style={styles.header}>
                    <View>
                        <Text style={styles.greetingTitle}>Good morning, {userName.split(' ')[0]}</Text>
                        <Text style={styles.greetingSubtitle}>Your city is better because of you.</Text>
                    </View>
                    <View style={styles.headerRight}>
                        <TouchableOpacity style={styles.iconButton}>
                            <Ionicons name="notifications-outline" size={24} color="#333" />
                        </TouchableOpacity>
                        <Image
                            source={{ uri: 'https://randomuser.me/api/portraits/men/32.jpg' }} // Placeholder user image
                            style={styles.avatar}
                        />
                    </View>
                </View>

                {loading ? (
                    <ActivityIndicator size="large" color="#00D2D3" style={{ marginVertical: 20 }} />
                ) : (
                    <>
                        {/* Stats Card */}
                        <View style={styles.statsCard}>
                            <View style={styles.statsHeader}>
                                <Ionicons name="checkmark-circle" size={24} color="#00D2D3" />
                                <Text style={styles.statsTitle}>Total Issues Solved</Text>
                                <Ionicons name="shield-checkmark-outline" size={24} color="#A4B0BE" style={{ marginLeft: 'auto' }} />
                            </View>
                            <Text style={styles.statsCount}>{stats.resolved}</Text>
                            <Text style={styles.statsLabel}>successful reports out of {stats.total} total</Text>
                        </View>

                        {/* Recent Activity Section */}
                        <View style={styles.sectionHeader}>
                            <Text style={styles.sectionTitle}>Recent Activity</Text>
                            <TouchableOpacity onPress={() => navigation.navigate('My Issues')}>
                                <Text style={styles.seeAllText}>See All</Text>
                            </TouchableOpacity>
                        </View>

                        {/* Static for now, as API endpoint for recent activity list isn't separate yet, or we can fetch last few my-issues */}
                        <View style={styles.activityCard}>
                            <View style={styles.activityInfo}>
                                <View style={styles.statusRow}>
                                    <View style={[styles.statusDot, { backgroundColor: '#54a0ff' }]} />
                                    <Text style={[styles.statusText, { color: '#54a0ff' }]}>IN PROGRESS</Text>
                                </View>
                                <Text style={styles.activityTitle}>Sample Issue</Text>
                                <Text style={styles.activityDate}>Tracking active reports...</Text>
                                <TouchableOpacity style={styles.trackButton} onPress={() => navigation.navigate('My Issues')}>
                                    <Text style={styles.trackButtonText}>Track Progress</Text>
                                </TouchableOpacity>
                            </View>
                        </View>

                    </>
                )}

                {/* Help Neighbors Card */}
                <LinearGradient
                    colors={['#0097e6', '#00D2D3']}
                    start={{ x: 0, y: 0 }}
                    end={{ x: 1, y: 1 }}
                    style={styles.helpCard}
                >
                    <View style={styles.helpContent}>
                        <Text style={styles.helpTitle}>Help your neighbors</Text>
                        <Text style={styles.helpSubtitle}>Check the map to verify nearby reports.</Text>
                        <TouchableOpacity style={styles.mapButton} onPress={() => navigation.navigate('Map')}>
                            <Text style={styles.mapButtonText}>Open Map</Text>
                        </TouchableOpacity>
                    </View>
                    <Ionicons name="location" size={100} color="rgba(255,255,255,0.2)" style={styles.mapIconBg} />
                </LinearGradient>

                {/* Bottom padding for tab bar */}
                <View style={{ height: 100 }} />

            </ScrollView>
        </SafeAreaView>
    );
};

const styles = StyleSheet.create({
    container: {
        flex: 1,
        backgroundColor: '#F7F9FC',
    },
    scrollContent: {
        padding: 20,
    },
    header: {
        flexDirection: 'row',
        justifyContent: 'space-between',
        alignItems: 'center',
        marginBottom: 25,
    },
    greetingTitle: {
        fontSize: 22,
        fontWeight: 'bold',
        color: '#2d3436',
    },
    greetingSubtitle: {
        fontSize: 14,
        color: '#636e72',
        marginTop: 2,
    },
    headerRight: {
        flexDirection: 'row',
        alignItems: 'center',
    },
    iconButton: {
        width: 40,
        height: 40,
        borderRadius: 20,
        backgroundColor: '#fff',
        alignItems: 'center',
        justifyContent: 'center',
        marginRight: 10,
        shadowColor: '#000',
        shadowOffset: { width: 0, height: 1 },
        shadowOpacity: 0.1,
        shadowRadius: 2,
        elevation: 2,
    },
    avatar: {
        width: 40,
        height: 40,
        borderRadius: 20,
        borderWidth: 2,
        borderColor: '#fff',
    },
    statsCard: {
        backgroundColor: '#E6F7F8', // Light teal background
        borderRadius: 20,
        padding: 20,
        marginBottom: 25,
    },
    statsHeader: {
        flexDirection: 'row',
        alignItems: 'center',
        marginBottom: 10,
    },
    statsTitle: {
        fontSize: 16,
        fontWeight: '600',
        color: '#2d3436',
        marginLeft: 8,
    },
    statsCount: {
        fontSize: 42,
        fontWeight: 'bold',
        color: '#2d3436',
    },
    statsLabel: {
        fontSize: 14,
        color: '#00D2D3', // Teal text
        fontWeight: '500',
    },
    sectionHeader: {
        flexDirection: 'row',
        justifyContent: 'space-between',
        alignItems: 'center',
        marginBottom: 15,
    },
    sectionTitle: {
        fontSize: 18,
        fontWeight: 'bold',
        color: '#2d3436',
    },
    seeAllText: {
        fontSize: 14,
        color: '#00D2D3',
        fontWeight: '600',
    },
    activityCard: {
        backgroundColor: '#fff',
        borderRadius: 20,
        padding: 15,
        flexDirection: 'row',
        marginBottom: 15,
        shadowColor: '#000',
        shadowOffset: { width: 0, height: 2 },
        shadowOpacity: 0.05,
        shadowRadius: 10,
        elevation: 3,
    },
    activityInfo: {
        flex: 1,
        paddingRight: 10,
    },
    statusRow: {
        flexDirection: 'row',
        alignItems: 'center',
        marginBottom: 5,
    },
    statusDot: {
        width: 8,
        height: 8,
        borderRadius: 4,
        marginRight: 6,
    },
    statusText: {
        fontSize: 12,
        fontWeight: '700',
        letterSpacing: 0.5,
    },
    activityTitle: {
        fontSize: 16,
        fontWeight: 'bold',
        color: '#2d3436',
        marginBottom: 4,
    },
    activityDate: {
        fontSize: 12,
        color: '#b2bec3',
        marginBottom: 12,
    },
    trackButton: {
        backgroundColor: '#E6F7F8',
        paddingVertical: 8,
        paddingHorizontal: 15,
        borderRadius: 20,
        alignSelf: 'flex-start',
    },
    trackButtonText: {
        color: '#00D2D3',
        fontSize: 12,
        fontWeight: '600',
    },
    helpCard: {
        borderRadius: 25,
        padding: 25,
        flexDirection: 'row',
        position: 'relative',
        overflow: 'hidden',
        marginTop: 10,
    },
    helpContent: {
        flex: 1,
        zIndex: 1,
    },
    helpTitle: {
        fontSize: 20,
        fontWeight: 'bold',
        color: '#fff',
        marginBottom: 5,
    },
    helpSubtitle: {
        fontSize: 14,
        color: 'rgba(255,255,255,0.9)',
        marginBottom: 15,
        lineHeight: 20,
    },
    mapButton: {
        backgroundColor: '#fff',
        paddingVertical: 10,
        paddingHorizontal: 20,
        borderRadius: 20,
        alignSelf: 'flex-start',
    },
    mapButtonText: {
        color: '#0097e6',
        fontWeight: 'bold',
        fontSize: 14,
    },
    mapIconBg: {
        position: 'absolute',
        bottom: -20,
        right: -20,
        transform: [{ rotate: '-15deg' }],
    },
});

export default HomeScreen;
