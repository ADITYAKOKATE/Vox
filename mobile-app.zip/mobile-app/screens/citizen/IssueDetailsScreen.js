import React from 'react';
import { View, Text, StyleSheet, ScrollView, Image, TouchableOpacity, Dimensions } from 'react-native';
import { SafeAreaView } from 'react-native-safe-area-context';
import { Ionicons } from '@expo/vector-icons';
import MapView, { Marker, PROVIDER_GOOGLE } from '../../components/NativeMap';

const { width } = Dimensions.get('window');

const IssueDetailsScreen = ({ route, navigation }) => {
    const { issue } = route.params;

    const getStatusColor = (status) => {
        switch (status) {
            case 'Resolved': return '#1dd1a1';
            case 'In Progress': return '#54a0ff';
            case 'Rejected': return '#ff6b6b';
            default: return '#feca57'; // Pending
        }
    };

    const statusColor = getStatusColor(issue.status);

    // Parse coordinates safely
    const coords = issue.location?.coordinates || { lat: 0, lng: 0 };
    const hasLocation = coords.lat !== 0 && coords.lng !== 0;

    let imageSource = { uri: 'https://via.placeholder.com/300' };
    if (issue.image && issue.image.startsWith('http')) {
        imageSource = { uri: issue.image };
    }

    return (
        <SafeAreaView style={styles.container}>
            {/* Header */}
            <View style={styles.header}>
                <TouchableOpacity onPress={() => navigation.goBack()} style={styles.backButton}>
                    <Ionicons name="arrow-back" size={24} color="#2d3436" />
                </TouchableOpacity>
                <Text style={styles.headerTitle}>Issue Details</Text>
                <View style={{ width: 24 }} />
            </View>

            <ScrollView contentContainerStyle={styles.scrollContent} showsVerticalScrollIndicator={false}>

                {/* Status Banner */}
                <View style={[styles.statusBanner, { backgroundColor: statusColor + '20' }]}>
                    <Ionicons name="information-circle" size={20} color={statusColor} style={{ marginRight: 8 }} />
                    <Text style={[styles.statusText, { color: statusColor }]}>Status: {issue.status.toUpperCase()}</Text>
                </View>

                {/* Title & Date */}
                <Text style={styles.title}>{issue.title}</Text>
                <Text style={styles.date}>Reported on {new Date(issue.createdAt).toLocaleDateString()} at {new Date(issue.createdAt).toLocaleTimeString()}</Text>

                {/* Main Image */}
                <View style={styles.imageContainer}>
                    <Image source={imageSource} style={styles.mainImage} />
                    <View style={styles.typeTag}>
                        <Text style={styles.typeText}>{issue.type}</Text>
                    </View>
                </View>

                {/* Description */}
                <View style={styles.section}>
                    <Text style={styles.sectionTitle}>Description</Text>
                    <Text style={styles.description}>{issue.description}</Text>
                </View>

                {/* Location Map */}
                <View style={styles.section}>
                    <Text style={styles.sectionTitle}>Location</Text>
                    <View style={styles.locationContainer}>
                        <Ionicons name="location-sharp" size={16} color="#636e72" />
                        <Text style={styles.addressText}>{issue.location?.address || 'Unknown Location'}</Text>
                    </View>

                    {hasLocation ? (
                        <View style={styles.mapContainer}>
                            <MapView
                                style={styles.map}
                                // provider={PROVIDER_GOOGLE}
                                scrollEnabled={false}
                                zoomEnabled={false}
                                initialRegion={{
                                    latitude: coords.lat,
                                    longitude: coords.lng,
                                    latitudeDelta: 0.005,
                                    longitudeDelta: 0.005,
                                }}
                            >
                                <Marker
                                    coordinate={{ latitude: coords.lat, longitude: coords.lng }}
                                    pinColor={statusColor}
                                />
                            </MapView>
                        </View>
                    ) : (
                        <View style={[styles.mapContainer, { justifyContent: 'center', alignItems: 'center' }]}>
                            <Text style={{ color: '#b2bec3' }}>No map data available</Text>
                        </View>
                    )}
                </View>

                {/* Timeline Placeholder */}
                <View style={styles.section}>
                    <Text style={styles.sectionTitle}>Updates</Text>
                    <View style={styles.timelineItem}>
                        <View style={styles.timelineDot} />
                        <View style={styles.timelineContent}>
                            <Text style={styles.timelineText}>Report received by system</Text>
                            <Text style={styles.timelineDate}>{new Date(issue.createdAt).toLocaleDateString()}</Text>
                        </View>
                    </View>
                    {issue.status !== 'Pending' && (
                        <View style={styles.timelineItem}>
                            <View style={[styles.timelineDot, { backgroundColor: statusColor }]} />
                            <View style={styles.timelineContent}>
                                <Text style={styles.timelineText}>Status changed to {issue.status}</Text>
                                <Text style={styles.timelineDate}>Recently</Text>
                            </View>
                        </View>
                    )}
                </View>

                <View style={{ height: 50 }} />

            </ScrollView>
        </SafeAreaView>
    );
};

const styles = StyleSheet.create({
    container: {
        flex: 1,
        backgroundColor: '#F7F9FC',
    },
    header: {
        flexDirection: 'row',
        alignItems: 'center',
        justifyContent: 'space-between',
        paddingHorizontal: 20,
        paddingVertical: 15,
        backgroundColor: '#fff',
        borderBottomWidth: 1,
        borderBottomColor: '#f1f2f6',
    },
    headerTitle: {
        fontSize: 18,
        fontWeight: 'bold',
        color: '#2d3436',
    },
    scrollContent: {
        padding: 20,
    },
    statusBanner: {
        flexDirection: 'row',
        alignItems: 'center',
        padding: 12,
        borderRadius: 10,
        marginBottom: 20,
    },
    statusText: {
        fontWeight: 'bold',
        fontSize: 14,
    },
    title: {
        fontSize: 24,
        fontWeight: 'bold',
        color: '#2d3436',
        marginBottom: 5,
    },
    date: {
        fontSize: 12,
        color: '#b2bec3',
        marginBottom: 20,
    },
    imageContainer: {
        width: '100%',
        height: 200,
        borderRadius: 15,
        overflow: 'hidden',
        marginBottom: 25,
        position: 'relative'
    },
    mainImage: {
        width: '100%',
        height: '100%',
        resizeMode: 'cover',
    },
    typeTag: {
        position: 'absolute',
        top: 10,
        left: 10,
        backgroundColor: 'rgba(0,0,0,0.6)',
        paddingHorizontal: 10,
        paddingVertical: 5,
        borderRadius: 15,
    },
    typeText: {
        color: '#fff',
        fontWeight: 'bold',
        fontSize: 12,
    },
    section: {
        marginBottom: 30,
    },
    sectionTitle: {
        fontSize: 16,
        fontWeight: 'bold',
        color: '#2d3436',
        marginBottom: 10,
    },
    description: {
        fontSize: 14,
        color: '#636e72',
        lineHeight: 22,
    },
    locationContainer: {
        flexDirection: 'row',
        alignItems: 'center',
        marginBottom: 10,
    },
    addressText: {
        marginLeft: 8,
        fontSize: 14,
        color: '#636e72',
    },
    mapContainer: {
        width: '100%',
        height: 150,
        borderRadius: 15,
        overflow: 'hidden',
        backgroundColor: '#dfe6e9',
    },
    map: {
        width: '100%',
        height: '100%',
    },
    timelineItem: {
        flexDirection: 'row',
        marginBottom: 15,
    },
    timelineDot: {
        width: 12,
        height: 12,
        borderRadius: 6,
        backgroundColor: '#dcdde1',
        marginTop: 5,
        marginRight: 15,
    },
    timelineContent: {
        flex: 1,
    },
    timelineText: {
        fontSize: 14,
        color: '#2d3436',
        fontWeight: '500',
    },
    timelineDate: {
        fontSize: 12,
        color: '#b2bec3',
        marginTop: 2,
    }
});

export default IssueDetailsScreen;
