import React, { useState, useEffect, useRef } from 'react';
import { View, Text, TextInput, TouchableOpacity, StyleSheet, Alert, ActivityIndicator, KeyboardAvoidingView, Platform, ScrollView, Animated } from 'react-native';
import axios from 'axios';
import { LinearGradient } from 'expo-linear-gradient';
import { Ionicons } from '@expo/vector-icons';

// Replace with your machine's local IP
const API_URL = 'http://10.145.135.40:5000/api/v1/auth';

export default function SignupScreen({ navigation }) {
    const [name, setName] = useState('');
    const [email, setEmail] = useState('');
    const [password, setPassword] = useState('');
    const [role, setRole] = useState('CITIZEN');
    const [loading, setLoading] = useState(false);

    // Animations
    const fadeAnim = useRef(new Animated.Value(0)).current;
    const slideAnim = useRef(new Animated.Value(50)).current;

    useEffect(() => {
        Animated.parallel([
            Animated.timing(fadeAnim, {
                toValue: 1,
                duration: 800,
                useNativeDriver: true,
            }),
            Animated.spring(slideAnim, {
                toValue: 0,
                friction: 7,
                tension: 40,
                useNativeDriver: true,
            })
        ]).start();
    }, []);

    const handleSignup = async () => {
        if (!name || !email || !password) {
            Alert.alert('Missing Info', 'Please fill in all fields to create your account.');
            return;
        }

        setLoading(true);
        try {
            const response = await axios.post(`${API_URL}/register`, {
                name,
                email,
                password,
                role
            });

            setLoading(false);
            Alert.alert(
                'Success! 🎉',
                'Your account has been created successfully.',
                [{ text: "Login Now", onPress: () => navigation.navigate('Login') }]
            );
        } catch (error) {
            setLoading(false);
            const msg = error.response?.data?.error || 'Something went wrong';
            Alert.alert('Signup Failed', msg);
        }
    };

    const RoleOption = ({ label, value, icon, color }) => (
        <TouchableOpacity
            style={[styles.roleOption, role === value && { backgroundColor: color, borderColor: color, transform: [{ scale: 1.05 }] }]}
            activeOpacity={0.8}
            onPress={() => setRole(value)}
        >
            <View style={[styles.roleIconContainer, role === value && { backgroundColor: 'rgba(255,255,255,0.2)' }]}>
                <Ionicons name={icon} size={24} color={role === value ? '#fff' : color} />
            </View>
            <Text style={[styles.roleText, role === value && styles.roleTextSelected]}>{label}</Text>
        </TouchableOpacity>
    );

    return (
        <LinearGradient colors={['#0F2027', '#203A43', '#2C5364']} style={styles.background}>
            <KeyboardAvoidingView behavior={Platform.OS === "ios" ? "padding" : "height"} style={styles.container}>
                <ScrollView contentContainerStyle={styles.scrollContent}>

                    <Animated.View style={[styles.header, { opacity: fadeAnim }]}>
                        <Text style={styles.title}>Join Us</Text>
                        <Text style={styles.subtitle}>Be a part of the change.</Text>
                    </Animated.View>

                    <Animated.View style={[styles.card, { opacity: fadeAnim, transform: [{ translateY: slideAnim }] }]}>

                        <Text style={styles.sectionLabel}>I am a...</Text>
                        <View style={styles.roleContainer}>
                            <RoleOption label="Citizen" value="CITIZEN" icon="person" color="#0984e3" />
                            <RoleOption label="Staff" value="STAFF" icon="briefcase" color="#00cec9" />
                            <RoleOption label="Admin" value="ADMIN" icon="shield" color="#6c5ce7" />
                        </View>

                        <View style={styles.formSection}>
                            <View style={styles.inputContainer}>
                                <Text style={styles.inputLabel}>Full Name</Text>
                                <View style={styles.inputGroup}>
                                    <Ionicons name="person-outline" size={20} color="#a0aec0" style={styles.inputIcon} />
                                    <TextInput
                                        style={styles.input}
                                        placeholder="John Doe"
                                        placeholderTextColor="#a0aec0"
                                        value={name}
                                        onChangeText={setName}
                                    />
                                </View>
                            </View>

                            <View style={styles.inputContainer}>
                                <Text style={styles.inputLabel}>Email Address</Text>
                                <View style={styles.inputGroup}>
                                    <Ionicons name="mail-outline" size={20} color="#a0aec0" style={styles.inputIcon} />
                                    <TextInput
                                        style={styles.input}
                                        placeholder="name@example.com"
                                        placeholderTextColor="#a0aec0"
                                        value={email}
                                        onChangeText={setEmail}
                                        autoCapitalize="none"
                                        keyboardType="email-address"
                                    />
                                </View>
                            </View>

                            <View style={styles.inputContainer}>
                                <Text style={styles.inputLabel}>Password</Text>
                                <View style={styles.inputGroup}>
                                    <Ionicons name="lock-closed-outline" size={20} color="#a0aec0" style={styles.inputIcon} />
                                    <TextInput
                                        style={styles.input}
                                        placeholder="Create a password"
                                        placeholderTextColor="#a0aec0"
                                        value={password}
                                        onChangeText={setPassword}
                                        secureTextEntry
                                    />
                                </View>
                            </View>
                        </View>

                        <TouchableOpacity activeOpacity={0.8} onPress={handleSignup} disabled={loading}>
                            <LinearGradient colors={['#6c5ce7', '#a29bfe']} style={styles.gradientButton} start={{ x: 0, y: 0 }} end={{ x: 1, y: 0 }}>
                                {loading ? (
                                    <ActivityIndicator color="#fff" />
                                ) : (
                                    <View style={styles.btnContent}>
                                        <Text style={styles.buttonText}>Create Account</Text>
                                        <Ionicons name="arrow-forward" size={20} color="#fff" style={{ marginLeft: 10 }} />
                                    </View>
                                )}
                            </LinearGradient>
                        </TouchableOpacity>

                        <TouchableOpacity onPress={() => navigation.goBack()} style={styles.footerLinkContainer}>
                            <Text style={styles.footerText}>Already have an account? <Text style={styles.linkBold}>Log In</Text></Text>
                        </TouchableOpacity>

                    </Animated.View>
                </ScrollView>
            </KeyboardAvoidingView>
        </LinearGradient>
    );
}

const styles = StyleSheet.create({
    background: {
        flex: 1,
    },
    container: {
        flex: 1,
    },
    scrollContent: {
        flexGrow: 1,
        justifyContent: 'center',
        padding: 24,
    },
    header: {
        alignItems: 'center',
        marginBottom: 30,
    },
    title: {
        fontSize: 32,
        fontWeight: '800',
        color: '#fff',
        letterSpacing: 1,
    },
    subtitle: {
        fontSize: 16,
        color: '#b2bec3',
        marginTop: 5,
    },
    card: {
        backgroundColor: 'rgba(255, 255, 255, 0.95)',
        borderRadius: 30,
        padding: 25,
        shadowColor: "#000",
        shadowOffset: { width: 0, height: 20 },
        shadowOpacity: 0.25,
        shadowRadius: 25,
        elevation: 20,
    },
    sectionLabel: {
        fontSize: 14,
        color: '#636e72',
        marginBottom: 15,
        fontWeight: '700',
        letterSpacing: 0.5,
        textTransform: 'uppercase',
    },
    roleContainer: {
        flexDirection: 'row',
        justifyContent: 'space-between',
        marginBottom: 30,
    },
    roleOption: {
        flex: 1,
        alignItems: 'center',
        paddingVertical: 15,
        borderRadius: 15,
        borderWidth: 1,
        borderColor: '#dfe6e9',
        marginHorizontal: 5,
        backgroundColor: '#fff',
        shadowColor: "#000",
        shadowOffset: { width: 0, height: 2 },
        shadowOpacity: 0.05,
        shadowRadius: 3,
        elevation: 2,
    },
    roleIconContainer: {
        marginBottom: 8,
        padding: 8,
        borderRadius: 12,
    },
    roleText: {
        fontSize: 12,
        color: '#636e72',
        fontWeight: '600',
    },
    roleTextSelected: {
        color: '#fff',
        fontWeight: 'bold',
    },
    formSection: {
        marginBottom: 20,
    },
    inputContainer: {
        marginBottom: 15,
    },
    inputLabel: {
        fontSize: 12,
        fontWeight: '600',
        color: '#636e72',
        marginBottom: 6,
        marginLeft: 4,
    },
    inputGroup: {
        flexDirection: 'row',
        alignItems: 'center',
        backgroundColor: '#f1f2f6',
        borderRadius: 12,
        paddingHorizontal: 15,
        height: 50,
        borderWidth: 1,
        borderColor: '#dfe6e9',
    },
    inputIcon: {
        marginRight: 10,
    },
    input: {
        flex: 1,
        height: 48,
        fontSize: 16,
        color: '#2d3436',
        fontWeight: '500',
    },
    gradientButton: {
        borderRadius: 15,
        height: 55,
        justifyContent: 'center',
        alignItems: 'center',
        shadowColor: "#6c5ce7",
        shadowOffset: { width: 0, height: 8 },
        shadowOpacity: 0.3,
        shadowRadius: 8,
        elevation: 8,
        marginTop: 10,
    },
    btnContent: {
        flexDirection: 'row',
        alignItems: 'center',
    },
    buttonText: {
        color: '#fff',
        fontSize: 17,
        fontWeight: 'bold',
        letterSpacing: 0.5,
    },
    footerLinkContainer: {
        marginTop: 25,
        alignItems: 'center',
    },
    footerText: {
        color: '#636e72',
        fontSize: 14,
    },
    linkBold: {
        color: '#6c5ce7',
        fontWeight: 'bold',
    },
});
