import React, { useState, useEffect, useRef } from 'react';
import { View, Text, TextInput, TouchableOpacity, StyleSheet, Alert, ActivityIndicator, KeyboardAvoidingView, Platform, ScrollView, Animated, Dimensions } from 'react-native';
import axios from 'axios';
import AsyncStorage from '@react-native-async-storage/async-storage';
import { LinearGradient } from 'expo-linear-gradient';
import { Ionicons } from '@expo/vector-icons';

// Replace with your machine's local IP
const API_URL = 'http://10.145.135.40:5000/api/v1/auth';
const { width } = Dimensions.get('window');

export default function LoginScreen({ navigation }) {
    const [email, setEmail] = useState('');
    const [password, setPassword] = useState('');
    const [loading, setLoading] = useState(false);

    // Animations
    const fadeAnim = useRef(new Animated.Value(0)).current;
    const slideAnim = useRef(new Animated.Value(50)).current;

    useEffect(() => {
        Animated.parallel([
            Animated.timing(fadeAnim, {
                toValue: 1,
                duration: 1000,
                useNativeDriver: true,
            }),
            Animated.spring(slideAnim, {
                toValue: 0,
                friction: 6,
                tension: 40,
                useNativeDriver: true,
            })
        ]).start();
    }, []);

    const handleLogin = async () => {
        if (!email || !password) {
            Alert.alert('Missing Info', 'Please enter your email and password.');
            return;
        }

        setLoading(true);
        try {
            const response = await axios.post(`${API_URL}/login`, {
                email,
                password
            });

            setLoading(false);
            const { token, user } = response.data;
            await AsyncStorage.setItem('userToken', token);
            await AsyncStorage.setItem('userInfo', JSON.stringify(user));

            const role = user.role;
            let targetScreen = 'CitizenHome';
            if (role === 'STAFF') targetScreen = 'StaffHome';
            if (role === 'ADMIN') targetScreen = 'AdminHome';

            Alert.alert(
                'Success',
                `Welcome back, ${response.data.user.name}!`,
                [
                    { text: "Rocket In! 🚀", onPress: () => navigation.replace(targetScreen) }
                ]
            );
        } catch (error) {
            setLoading(false);
            const msg = error.response?.data?.error || 'Something went wrong';
            Alert.alert('Login Failed', msg);
        }
    };

    return (
        <LinearGradient colors={['#0F2027', '#203A43', '#2C5364']} style={styles.background}>
            <KeyboardAvoidingView behavior={Platform.OS === "ios" ? "padding" : "height"} style={styles.container}>
                <ScrollView contentContainerStyle={styles.scrollContent}>

                    <Animated.View style={[styles.header, { opacity: fadeAnim }]}>
                        <View style={styles.iconCircle}>
                            <Ionicons name="planet" size={50} color="#4bd1c5" />
                        </View>
                        <Text style={styles.title}>Civic Pulse</Text>
                        <Text style={styles.subtitle}>Empowering Citizens, Building Future.</Text>
                    </Animated.View>

                    <Animated.View style={[styles.card, { opacity: fadeAnim, transform: [{ translateY: slideAnim }] }]}>
                        <Text style={styles.loginTitle}>Welcome Back</Text>

                        <View style={styles.inputContainer}>
                            <Text style={styles.inputLabel}>Email</Text>
                            <View style={styles.inputGroup}>
                                <Ionicons name="mail-outline" size={20} color="#a0aec0" style={styles.inputIcon} />
                                <TextInput
                                    style={styles.input}
                                    placeholder="name@example.com"
                                    placeholderTextColor="#a0aec0"
                                    value={email}
                                    onChangeText={setEmail}
                                    autoCapitalize="none"
                                    keyboardType="email-address"
                                />
                            </View>
                        </View>

                        <View style={styles.inputContainer}>
                            <Text style={styles.inputLabel}>Password</Text>
                            <View style={styles.inputGroup}>
                                <Ionicons name="lock-closed-outline" size={20} color="#a0aec0" style={styles.inputIcon} />
                                <TextInput
                                    style={styles.input}
                                    placeholder="••••••••"
                                    placeholderTextColor="#a0aec0"
                                    value={password}
                                    onChangeText={setPassword}
                                    secureTextEntry
                                />
                            </View>
                        </View>

                        <TouchableOpacity style={styles.forgotBtn}>
                            <Text style={styles.forgotText}>Forgot Password?</Text>
                        </TouchableOpacity>

                        <TouchableOpacity activeOpacity={0.8} onPress={handleLogin} disabled={loading}>
                            <LinearGradient colors={['#4bd1c5', '#22a6b3']} style={styles.gradientButton} start={{ x: 0, y: 0 }} end={{ x: 1, y: 0 }}>
                                {loading ? (
                                    <ActivityIndicator color="#fff" />
                                ) : (
                                    <View style={styles.btnContent}>
                                        <Text style={styles.buttonText}>Log In</Text>
                                        <Ionicons name="arrow-forward-circle" size={24} color="#fff" style={{ marginLeft: 8 }} />
                                    </View>
                                )}
                            </LinearGradient>
                        </TouchableOpacity>

                    </Animated.View>

                    <Animated.View style={{ opacity: fadeAnim, transform: [{ translateY: slideAnim }] }}>
                        <TouchableOpacity onPress={() => navigation.navigate('Signup')} style={styles.footer}>
                            <Text style={styles.footerText}>Don't have an account? <Text style={styles.footerLink}>Sign Up</Text></Text>
                        </TouchableOpacity>
                    </Animated.View>

                </ScrollView>
            </KeyboardAvoidingView>
        </LinearGradient>
    );
}

const styles = StyleSheet.create({
    background: {
        flex: 1,
    },
    container: {
        flex: 1,
    },
    scrollContent: {
        flexGrow: 1,
        justifyContent: 'center',
        padding: 24,
    },
    header: {
        alignItems: 'center',
        marginBottom: 40,
    },
    iconCircle: {
        width: 100,
        height: 100,
        borderRadius: 50,
        backgroundColor: 'rgba(255,255,255,0.1)',
        justifyContent: 'center',
        alignItems: 'center',
        marginBottom: 20,
        borderWidth: 1,
        borderColor: 'rgba(75, 209, 197, 0.3)',
    },
    title: {
        fontSize: 36,
        fontWeight: '800',
        color: '#fff',
        letterSpacing: 1.5,
        fontFamily: Platform.OS === 'ios' ? 'Helvetica Neue' : 'sans-serif',
    },
    subtitle: {
        fontSize: 14,
        color: '#b2bec3',
        marginTop: 8,
        textAlign: 'center',
        letterSpacing: 1,
    },
    card: {
        backgroundColor: 'rgba(255, 255, 255, 0.95)',
        borderRadius: 30,
        padding: 30,
        shadowColor: "#000",
        shadowOffset: { width: 0, height: 20 },
        shadowOpacity: 0.25,
        shadowRadius: 25,
        elevation: 20,
    },
    loginTitle: {
        fontSize: 22,
        fontWeight: 'bold',
        color: '#2d3436',
        marginBottom: 25,
        textAlign: 'left',
    },
    inputContainer: {
        marginBottom: 20,
    },
    inputLabel: {
        fontSize: 12,
        fontWeight: '600',
        color: '#636e72',
        marginBottom: 8,
        textTransform: 'uppercase',
        letterSpacing: 1,
    },
    inputGroup: {
        flexDirection: 'row',
        alignItems: 'center',
        backgroundColor: '#f1f2f6',
        borderRadius: 15,
        paddingHorizontal: 15,
        height: 55,
        borderWidth: 1,
        borderColor: '#dfe6e9',
    },
    inputIcon: {
        marginRight: 15,
    },
    input: {
        flex: 1,
        height: 50,
        fontSize: 16,
        color: '#2d3436',
        fontWeight: '500',
    },
    forgotBtn: {
        alignItems: 'flex-end',
        marginBottom: 30,
    },
    forgotText: {
        color: '#0984e3',
        fontSize: 14,
        fontWeight: '600',
    },
    gradientButton: {
        borderRadius: 20,
        height: 60,
        justifyContent: 'center',
        alignItems: 'center',
        shadowColor: "#4bd1c5",
        shadowOffset: { width: 0, height: 10 },
        shadowOpacity: 0.4,
        shadowRadius: 10,
        elevation: 10,
    },
    btnContent: {
        flexDirection: 'row',
        alignItems: 'center',
    },
    buttonText: {
        color: '#fff',
        fontSize: 18,
        fontWeight: 'bold',
        letterSpacing: 1,
    },
    footer: {
        marginTop: 30,
        alignItems: 'center',
    },
    footerText: {
        color: '#b2bec3',
        fontSize: 15,
    },
    footerLink: {
        color: '#4bd1c5',
        fontWeight: 'bold',
    },
});
