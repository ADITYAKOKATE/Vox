import React from 'react';
import { View, Text, StyleSheet, TouchableOpacity } from 'react-native';

export default function AdminDashboard({ navigation }) {
    return (
        <View style={styles.container}>
            <Text style={styles.title}>Admin Panel</Text>
            <Text style={styles.text}>System overview and settings.</Text>

            <TouchableOpacity
                style={styles.button}
                onPress={() => navigation.replace('Login')}
            >
                <Text style={styles.buttonText}>Logout</Text>
            </TouchableOpacity>
        </View>
    );
}

const styles = StyleSheet.create({
    container: { flex: 1, justifyContent: 'center', alignItems: 'center', backgroundColor: '#efebe9' },
    title: { fontSize: 24, fontWeight: 'bold', marginBottom: 10 },
    text: { fontSize: 16, color: '#666', marginBottom: 20 },
    button: { backgroundColor: '#5d4037', padding: 10, borderRadius: 5 },
    buttonText: { color: '#fff' }
});
