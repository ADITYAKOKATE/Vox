import MapView, { Marker, Callout, PROVIDER_GOOGLE } from 'react-native-maps';

export default MapView;
export { Marker, Callout, PROVIDER_GOOGLE };
