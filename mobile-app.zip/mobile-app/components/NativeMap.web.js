import React from 'react';
import { View, Text, StyleSheet } from 'react-native';

const NativeMap = (props) => {
    return (
        <View style={[styles.container, props.style]}>
            <Text style={styles.text}>Map not supported on Web</Text>
        </View>
    );
};

const styles = StyleSheet.create({
    container: {
        backgroundColor: '#dfe6e9',
        justifyContent: 'center',
        alignItems: 'center',
    },
    text: {
        color: '#636e72',
    }
});

export default NativeMap;
export const Marker = () => null;
export const Callout = () => null;
export const PROVIDER_GOOGLE = 'google';
